import java.util.Scanner;  // Needed for the Scanner class
public class Mileage
{
   public static void main(String[] args)
   {
     // Add your declaration and code here.
     Scanner keyboard = new Scanner(System.in);
     double miles;//holds the miles driven
	 double gallons;//holds the gallons used
	 double milesPerGallons;//holds the miles per gallon
     //Print a line indicating this program will calculate mileage
     System.out.print("This program calculate mileage");
     //Print prompt to user asking for miles driven
     System.out.print("please enter your miles driven: ");
     //Read in miles driven
	 miles = keyboard.nextDouble();
     //Print prompt to user asking for gallons used
	 System.out.print("please enter your gallons used: ");
     //Read in gallons used
	 gallons = keyboard.nextDouble();
     //Calculate miles per gallon by dividing miles driven by gallons used
	 milesPerGallons=(miles/gallons);
     //Print miles per gallon along with appropriate labels
	 System.out.print("Your miles per gallon are "+milesPerGallons);
   }
}
