// TASK #2(Alternate)
// Add an import statement for the JOptionPane class
import javax.swing.JOptionPane;
public class AlternateNumericTypes
{
   public static void main(String[] args)
   {
      String firstName;//First name inputed
	  String lastName;//last name inputed
	  String fullName;//full combination of the 2 previous names
     //Task 2 Alternate
	  firstName= JOptionPane.showInputDialog("Please input your first name ");
      lastName= JOptionPane.showInputDialog("Please input your last name ");
      fullName = (firstName +" "+ lastName);
	  JOptionPane.showMessageDialog(null,"Your full name is "+fullName);

      System.out.println();      // To leave a blank line

   
   }
}