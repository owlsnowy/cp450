import java.util.Scanner;

public class presentValue
{
	public static void main(String[] args)
   {
	   double val1;
	   double val2;
	   double val3;
	   double value;
	   char letter;
	   Scanner keyboard = new Scanner(System.in);
	   
	   do{
   System.out.print("Enter the future value" );
              val1 = keyboard.nextDouble();
               System.out.print("Enter the intrest rate " );
               val2 = keyboard.nextDouble();
               System.out.print("Enter the number of years" );
               val3 = keyboard.nextDouble();
			   value = presentValue(val1,val2,val3);
			   System.out.println("the present value needed is " + value);
			   keyboard.nextLine(); // Consume the new line

         System.out.println("Do you want to exit " +
                            "the program (Y/N)?: ");
         String answer = keyboard.nextLine();
         letter = answer.charAt(0);

      } while(letter != 'Y' && letter != 'y');
	
   }
   public static double presentValue(double F,double r, double n){
   double P = F/Math.pow((1+r),n);
   return P;}
   }

