import java.util.Scanner;

import java.io.*;
public class Converter{
	public static void main(String[] args) throws IOException
   {
	   
		// Create an object of type Scanner
      Scanner keyboard = new Scanner (System.in);
	  String upperCase ;
	  String fileToConvert;
      String filenamein;     
	  String filenameout;
		System.out.print("Enter the file name for conversion:  ");
      filenamein = keyboard.nextLine();
	  System.out.print("Enter the file name for saving the conversion:  ");
      filenameout = keyboard.nextLine();
	  File file = new File (filenamein );
	  Scanner inputFile = new Scanner (file);
	  PrintWriter outputFile = new PrintWriter(filenameout);
	  
	 
	  
	  while (inputFile.hasNext())
       {
            // Read the next line.
            fileToConvert =inputFile.nextLine();
            //Convert to upper case
            upperCase =fileToConvert.toUpperCase();
            //Outputs to file
            outputFile.println(upperCase); 
           
            
        }
		outputFile.close();
		
   }
}