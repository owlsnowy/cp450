import java.util.Random;

public class dicegame
{
   public static void main(String[] args)
   {
      

      // A random number generator used in
      // simulating the rolling of dice
      Random generator = new Random();

      int die1Value;       // Value of the first die
      int die2Value;       // Value of the second die
      int com = 0;       // Total number of dice rolls
      int user = 0;   // Number of snake eyes rolls
      

      
		for(int i = 0;i<10;i++){
			die1Value = generator.nextInt(7);
			die2Value = generator.nextInt(7);
			if(die1Value < die2Value){
				com++;
				}
			else if(die1Value > die2Value){
					user++;
				}
			
		}
      // Display the results
	  if(user < com){
				System.out.println ("the computer wins");
				}
			else if(user > com){
					System.out.println ("the user wins");
				}
	}			
} 