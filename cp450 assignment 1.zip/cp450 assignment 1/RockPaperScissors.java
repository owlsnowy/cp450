import java.util.Random;
import java.util.Scanner;
public class RockPaperScissors
{
	public static void main(String[] args)
   {
   boolean victory;
   int die1Value;
   int die2Value;
   Scanner keyboard = new Scanner(System.in);
   Random generator = new Random();
   String val1;
   die1Value = generator.nextInt(2);
   do{
   System.out.print("please choose rock, paper, or scissors" );
   val1 = keyboard.nextLine();
   if(val1 == "rock"){
   die2Value = 0;
   }else if(val1 == "paper"){
   die2Value=1;
   }else {
   die2Value=2;
   }
   if(die2Value == die1Value){
   System.out.print("play again");
   victory = false;
   }else if (die1Value == 2 && die2Value ==1){
   System.out.print("Scissors cut paper");
    System.out.print("CPU WINS");
   victory = true;
   }else if (die1Value == 1 && die2Value ==0){
   System.out.print("Paper wraps rock");
   System.out.print("CPU WINS");
   victory = true;
   }else if (die1Value == 0 && die2Value ==2){
   System.out.print("Rock smashes scissors");
   System.out.print("CPU WINS");
   victory = true;
   }else if (die2Value == 2 && die1Value ==1){
   System.out.print("Scissors cut paper");
   System.out.print("USER WINS");
   victory = true;
   }else if (die2Value == 1 && die1Value ==0){
   System.out.print("Paper wraps rock");
   System.out.print("USER WINS");
   victory = true;
   }else if (die2Value == 0 && die1Value ==2){
   System.out.print("Rock smashes scissors");
   System.out.print("USER WINS");
   victory = true;
   }
   }while (victory = false);
   }
}