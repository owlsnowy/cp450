
import java.util.Random;
import java.util.Scanner;

public class SlotSimulation
{
	public static void main(String[] args)
   {
	    char letter;      // The user's Y or N decision
		Scanner keyboard = new Scanner(System.in);
   Random generator = new Random();
   int die1Value;       // Value of the first die
      
      int money;      
	   do{
    String hold= "";
      int ones = 0;   
      int twos = 0;        
      int threes = 0;      
      int fours = 0;      
      int fives = 0;  
	  int zeroes = 0;
	 
	  
	  System.out.print("Enter the amount of money you wish to use:  ");
      money = Integer.parseInt(keyboard.nextLine());
   for(int i=0;i<3;i++){
   die1Value = generator.nextInt(5);
				if(die1Value == 1){
					ones++;
					hold += "Oranges";
				}else if(die1Value == 2){
					twos++;
					hold += "Plums";
				}else if(die1Value == 3){
					threes++;
					hold += "Bells";
				}else if(die1Value == 4){
					fours++;
					hold += "Melons";
				}else if(die1Value == 5){
					fives++;
					hold += "Bars";
					}else if(die1Value == 0){
					zeroes++;
					hold += "Cherries";
					}
   }
   if (ones==2||twos==2||threes==2||fours==2||fives==2){
   money = money*2;
   }else if (ones==3||twos==3||threes==3||fours==3||fives==3){
   money = money*3;
   }else{
   money = money*0;
   }
   System.out.println ("You rolled " +
                          hold + " and won " +
                          money + " monies.");
	System.out.println("Do you want to exit program (Y/N)?: ");
         String answer = keyboard.nextLine();
         letter = answer.charAt(0);		
	} while(letter != 'Y' && letter != 'y');	
   }
}